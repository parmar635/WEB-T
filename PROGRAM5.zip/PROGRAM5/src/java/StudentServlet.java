import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentServlet extends HttpServlet {
    private static ArrayList<Student> students = new ArrayList<>();
    private static int idCounter = 1;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action == null) {
            showStudentList(response);
        } else if (action.equals("create")) {
            showCreateForm(response);
        } else if (action.equals("edit")) {
            showEditForm(request, response);
        } else if (action.equals("delete")) {
            deleteStudent(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if (action.equals("create")) {
            createStudent(request, response);
        } else if (action.equals("update")) {
            updateStudent(request, response);
        }
    }

    private void showStudentList(HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html><head><title>Student CRUD</title>");
        out.println("<style>table { border-collapse: collapse; width: 90%; margin: 20px auto; }");
        out.println("th, td { border: 1px solid black; padding: 8px; text-align: left; }");
        out.println("th { background-color: #f2f2f2; }");
        out.println("button { padding: 5px 10px; margin: 2px; }");
        out.println("</style></head><body>");
        out.println("<h1 style='text-align: center;'>Student Management</h1>");
        out.println("<div style='text-align: center;'><a href='StudentServlet?action=create'><button>Add New Student</button></a></div>");
        
        out.println("<table>");
        out.println("<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Age</th><th>Course</th><th>Actions</th></tr>");
        
        for (Student student : students) {
            out.println("<tr>");
            out.println("<td>" + student.getId() + "</td>");
            out.println("<td>" + student.getName() + "</td>");
            out.println("<td>" + student.getEmail() + "</td>");
            out.println("<td>" + student.getPhone() + "</td>");
            out.println("<td>" + student.getAddress() + "</td>");
            out.println("<td>" + student.getAge() + "</td>");
            out.println("<td>" + student.getCourse() + "</td>");
            out.println("<td>");
            out.println("<a href='StudentServlet?action=edit&id=" + student.getId() + "'><button>Edit</button></a>");
            out.println("<a href='StudentServlet?action=delete&id=" + student.getId() + "'><button>Delete</button></a>");
            out.println("</td>");
            out.println("</tr>");
        }
        
        out.println("</table></body></html>");
    }

    private void showCreateForm(HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html><head><title>Create Student</title>");
        out.println("<style>.container { width: 400px; margin: 50px auto; }");
        out.println("input[type=text], input[type=email], input[type=number] { width: 100%; padding: 8px; margin: 5px 0; }");
        out.println("button { padding: 8px 15px; margin: 5px 0; }");
        out.println("</style></head><body>");
        out.println("<div class='container'>");
        out.println("<h2>Add New Student</h2>");
        out.println("<form action='StudentServlet' method='post'>");
        out.println("<input type='hidden' name='action' value='create'>");
        out.println("Name: <input type='text' name='name' required><br>");
        out.println("Email: <input type='email' name='email' required><br>");
        out.println("Phone: <input type='text' name='phone' required><br>");
        out.println("Address: <input type='text' name='address' required><br>");
        out.println("Age: <input type='number' name='age' required><br>");
        out.println("Course: <input type='text' name='course' required><br>");
        out.println("<button type='submit'>Create</button>");
        out.println("<a href='StudentServlet'><button type='button'>Cancel</button></a>");
        out.println("</form></div></body></html>");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Student student = findStudentById(id);
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html><head><title>Edit Student</title>");
        out.println("<style>.container { width: 400px; margin: 50px auto; }");
        out.println("input[type=text], input[type=email], input[type=number] { width: 100%; padding: 8px; margin: 5px 0; }");
        out.println("button { padding: 8px 15px; margin: 5px 0; }");
        out.println("</style></head><body>");
        out.println("<div class='container'>");
        out.println("<h2>Edit Student</h2>");
        out.println("<form action='StudentServlet' method='post'>");
        out.println("<input type='hidden' name='action' value='update'>");
        out.println("<input type='hidden' name='id' value='" + student.getId() + "'>");
        out.println("Name: <input type='text' name='name' value='" + student.getName() + "' required><br>");
        out.println("Email: <input type='email' name='email' value='" + student.getEmail() + "' required><br>");
        out.println("Phone: <input type='text' name='phone' value='" + student.getPhone() + "' required><br>");
        out.println("Address: <input type='text' name='address' value='" + student.getAddress() + "' required><br>");
        out.println("Age: <input type='number' name='age' value='" + student.getAge() + "' required><br>");
        out.println("Course: <input type='text' name='course' value='" + student.getCourse() + "' required><br>");
        out.println("<button type='submit'>Update</button>");
        out.println("<a href='StudentServlet'><button type='button'>Cancel</button></a>");
        out.println("</form></div></body></html>");
    }

    private void createStudent(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        int age = Integer.parseInt(request.getParameter("age"));
        String course = request.getParameter("course");
        
        students.add(new Student(idCounter++, name, email, phone, address, age, course));
        response.sendRedirect("StudentServlet");
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        int age = Integer.parseInt(request.getParameter("age"));
        String course = request.getParameter("course");
        
        Student student = findStudentById(id);
        if (student != null) {
            student.setName(name);
            student.setEmail(email);
            student.setPhone(phone);
            student.setAddress(address);
            student.setAge(age);
            student.setCourse(course);
        }
        response.sendRedirect("StudentServlet");
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Student student = findStudentById(id);
        if (student != null) {
            students.remove(student);
        }
        response.sendRedirect("StudentServlet");
    }

    private Student findStudentById(int id) {
        for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }
}