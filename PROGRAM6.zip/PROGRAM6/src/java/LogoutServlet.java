import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();
        String name = (String) session.getAttribute("username");
        Date startTime = (Date) session.getAttribute("startTime");
        
        // Calculate duration
        long durationMillis = new Date().getTime() - startTime.getTime();
        long seconds = durationMillis / 1000;
        long minutes = seconds / 60;
        seconds = seconds % 60;
        
        // Invalidate session
        session.invalidate();
        
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Logout Page</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 20px; text-align: center; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Thank you " + name + "</h1>");
        out.println("<p>Session duration: " + minutes + " minutes and " + seconds + " seconds</p>");
        out.println("</body>");
        out.println("</html>");
    }
}