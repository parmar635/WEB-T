import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String name = request.getParameter("name");
        HttpSession session = request.getSession();
        
        // Store name and start time in session
        session.setAttribute("username", name);
        session.setAttribute("startTime", new Date());
        
        // Handle visit counter
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 1;
        } else {
            visitCount++;
        }
        session.setAttribute("visitCount", visitCount);
        
        showWelcomePage(response, session, name, visitCount);
    }
    
    private void showWelcomePage(HttpServletResponse response, HttpSession session, 
            String name, int visitCount) throws IOException {
        PrintWriter out = response.getWriter();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
        String startTime = sdf.format((Date)session.getAttribute("startTime"));
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Welcome Page</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 20px; }");
        out.println(".time { position: absolute; top: 10px; right: 10px; }");
        out.println("button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='time'>Start Time: " + startTime + "</div>");
        out.println("<h1>Hello " + name + "</h1>");
        out.println("<h3>Session Information:</h3>");
        
        // Display all session attributes
        out.println("<ul>");
        Enumeration<String> attributes = session.getAttributeNames();
        while (attributes.hasMoreElements()) {
            String attrName = attributes.nextElement();
            out.println("<li>" + attrName + ": " + session.getAttribute(attrName) + "</li>");
        }
        out.println("</ul>");
        
        out.println("<p>Number of visits: " + visitCount + "</p>");
        out.println("<form action='LogoutServlet' method='post'>");
        out.println("<button type='submit'>Logout</button>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }
}