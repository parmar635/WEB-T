import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Userservlet     extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        String address = request.getParameter("address");

        // Database connection
        Connection con = null;
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the "emp" database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp", "root", "admin");

            // Begin transaction
            con.setAutoCommit(false);

            // SQL query to insert user data
            String sql = "INSERT INTO user (first_name, last_name, email, mobile, address) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(sql);

            // Set parameters
            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, email);
            pstmt.setString(4, mobile);
            pstmt.setString(5, address);

            // Execute the update
            int rowsInserted = pstmt.executeUpdate();

            // Commit transaction if successful
            if (rowsInserted > 0) {
                con.commit();
                response.sendRedirect("edit-user.html"); // Redirect to a success page
            } else {
                con.rollback();
                response.getWriter().write("Error: User registration failed.");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().write("Database driver not found: " + e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Database error: " + e.getMessage());
            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
                response.getWriter().write("Rollback error: " + rollbackEx.getMessage());
            }
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().write("Error closing database: " + e.getMessage());
            }
        }
    }
}
