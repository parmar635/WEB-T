function validate() {
    let principal = document.getElementById('principal').value;
    let rate = document.getElementById('rate').value;
    //let month = document.getElementById('month').value;
    const monthInput = document.getElementById('month').value;

            // Convert the input to a number
            const month = parseInt(monthInput, 10);

            // Validate the range
            if (isNaN(month) || month < 0 || month > 12) {
                alert("Please enter a valid month between 0 and 12.");
                return false;
            }

    // Validate Principal
    if (!/^[1-9][0-9]*$/.test(principal)) {
        alert("Principal amount must be a valid number (digits only) and greater than 0.");
        return false;
    }

    // Validate Rate
    if (!/^(10|[1-9])$/.test(rate)) {
        alert("Rate must be a valid number between 1 and 10.");
        return false;
    }

    // Validate Month
    //if (!/^(0|[1-9]|1[0-2])$/.test(month)) {
      //  alert("Month must be a valid number between 0 and 12.");
       // return false;
    //}

    return true;
}
