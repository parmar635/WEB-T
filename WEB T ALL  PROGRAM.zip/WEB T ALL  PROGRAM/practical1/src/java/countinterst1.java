/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */


public class countinterst1 extends HttpServlet {

    @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        double principal = Double.parseDouble(request.getParameter("principal"));
        double rate = Double.parseDouble(request.getParameter("rate"));
        int year = Integer.parseInt(request.getParameter("year"));
        int month = Integer.parseInt(request.getParameter("month"));
        int interval = Integer.parseInt(request.getParameter("interval"));

        double time = year + (month / 12.0);



         double compoundFactor =principal * Math.pow(1 + rate / (100 * interval), interval * time);
        
        double interest = compoundFactor - principal;


        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

      
        out.println("<html><body>");
        out.println("<h2>Compound Interest Calculation Result</h2>");
        out.println("<p>Principal: " + principal + "</p>");
        out.println("<p>Rate: " + rate + "%</p>");
        out.println("<p>Number of times interest is compounded per year: " + year + "</p>");
        out.println("<p>month (in years): " + month + "</p>");
        out.println("<p>Interest Earned: " + Math.round(interest) + "</p>");
        out.println("<p>final amount:"+compoundFactor+"</p>");
        out.println("</body></html>");
    }
}

