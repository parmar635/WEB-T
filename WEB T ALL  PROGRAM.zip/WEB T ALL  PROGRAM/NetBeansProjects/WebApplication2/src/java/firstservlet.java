import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class firstservlet extends HttpServlet {

    // Override init method to access init parameters
    @Override
    public void init() throws ServletException {
        super.init();
        // You can also log or process init parameters here if needed
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set response content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Print HTML structure
        out.println("<html><body>");
        out.println("<h2>Servlet Information and Request Details</h2>");

        // 1. Print Servlet Init Parameters
        out.println("<h3>Servlet Init Parameters:</h3>");
        out.println("<ul>");
        // Loop through all init parameters and display them
        getServletConfig().getInitParameterNames().asIterator().forEachRemaining(paramName -> {
            String paramValue = getServletConfig().getInitParameter(paramName);
            out.println("<li><b>" + paramName + "</b>: " + paramValue + "</li>");
        });
        out.println("</ul>");

        // 2. Print HTTP Request Headers
        out.println("<h3>HTTP Request Headers:</h3>");
        out.println("<ul>");
        // Loop through all headers and display them
        request.getHeaderNames().asIterator().forEachRemaining(headerName -> {
            String headerValue = request.getHeader(headerName);
            out.println("<li><b>" + headerName + "</b>: " + headerValue + "</li>");
        });
        out.println("</ul>");

        // 3. Print Client/Browser Information (from User-Agent header)
        String userAgent = request.getHeader("User-Agent");
        out.println("<h3>Client/Browser Information:</h3>");
        out.println("<p><b>User-Agent:</b> " + userAgent + "</p>");

        // 4. Print Server Information
        String serverName = request.getServerName();
        int serverPort = request.getServerPort();
        String serverAddress = request.getLocalAddr();
        out.println("<h3>Server Information:</h3>");
        out.println("<p><b>Server Name:</b> " + serverName + "</p>");
        out.println("<p><b>Server Port:</b> " + serverPort + "</p>");
        out.println("<p><b>Server Address:</b> " + serverAddress + "</p>");

        out.println("</body></html>");
    }
}
