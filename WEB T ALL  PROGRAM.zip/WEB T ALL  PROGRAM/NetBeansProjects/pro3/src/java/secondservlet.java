import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class secondservlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        String address = request.getParameter("address");
        String role = request.getParameter("role");

        // Database connection
        Connection con = null;
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user", "root", "admin");

            // Begin transaction
            con.setAutoCommit(false); // Disable auto-commit for transaction management

            // SQL query to insert user data into the "users" table
            String userSql = "INSERT INTO users (first_name, last_name, mobile, address) VALUES (?, ?, ?, ?)";
            PreparedStatement userStmt = con.prepareStatement(userSql);

            // Set parameters for the "users" table
            userStmt.setString(1, firstName);
            userStmt.setString(2, lastName);
            userStmt.setString(3, mobile);
            userStmt.setString(4, address);

            // Execute the first update
            int userRow = userStmt.executeUpdate();

            // SQL query to insert email and password into the "auth" table
            String login = "INSERT INTO login (email, password, role) VALUES (?, ?, ?)";
            PreparedStatement loginuser = con.prepareStatement(login);

            // Set parameters for the "auth" table
            loginuser.setString(1, email);
            loginuser.setString(2, password);
            loginuser.setString(3, role);

            // Execute the second update
            int authRow = loginuser.executeUpdate();

            // Commit the transaction if both inserts are successful
            if (userRow > 0 && authRow > 0) {
                con.commit(); // Commit transaction
                // Redirect to the login page
                response.sendRedirect("login.html");
            } else {
                con.rollback(); // Rollback transaction in case of failure
                response.getWriter().write("Error during registration.");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().write("Database driver not found: " + e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Database connection or query error: " + e.getMessage());
            try {
                if (con != null) {
                    con.rollback(); // Rollback transaction in case of an exception
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
                response.getWriter().write("Error during transaction rollback: " + rollbackEx.getMessage());
            }
        } catch (IOException e) {
            e.printStackTrace();
            response.getWriter().write("IO Error: " + e.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close(); // Close connection
                }
            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().write("Error closing the database connection: " + e.getMessage());
            }
        }
    }
}
