import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/user"; 
    private static final String DB_USER = "root"; 
    private static final String DB_PASSWORD = "admin"; 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        try {
           
            Class.forName("com.mysql.cj.jdbc.Driver");

         
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            
            String query = "SELECT role FROM login WHERE email = ? AND password = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, email);
            pst.setString(2, password);

            ResultSet rs = pst.executeQuery();

           
            if (rs.next()) {
            
                String dbRole = rs.getString("role");

                
                if (dbRole.equalsIgnoreCase(role)) {
                    
                    if ("admin".equalsIgnoreCase(role)) {
                        response.sendRedirect("admin.html"); // Admin page
                    } else if ("registered".equalsIgnoreCase(role)) {
                        response.sendRedirect("user.html");
                    } else {
                        showAlert(response, "Invalid role detected in the database.");
                    }
                } else {
                    showAlert(response, "Role mismatch! Please select the correct role.");
                }
            } else {
             
                showAlert(response, "User does not exist in the system.");
            }

   
            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            
            e.printStackTrace();
            showAlert(response, "Database connection error!");
        }
    }

    
    private void showAlert(HttpServletResponse response, String message) throws IOException {
        PrintWriter out = response.getWriter();
        out.println("<script type=\"text/javascript\">");
        out.println("alert('" + message + "');"); // Show alert message
        out.println("location='login.html';");     // Keep the user on the login page
        out.println("</script>");
    }
}
