import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/user"; 
    private static final String DB_USER = "root"; 
    private static final String DB_PASSWORD = "admin"; 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve form data
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        try {
            // Load the database driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL query to check user credentials
            String query = "SELECT role FROM login WHERE email = ? AND password = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, email);
            pst.setString(2, password);

            // Execute the query
            ResultSet rs = pst.executeQuery();

            // Check if the result set has data
            if (rs.next()) {
                // Retrieve the role from the database
                String dbRole = rs.getString("role");

                // Check if the role matches the role provided by the user
                if (dbRole.equalsIgnoreCase(role)) {
                    // Redirect based on role
                    if ("admin".equalsIgnoreCase(role)) {
                        response.sendRedirect("admin.html"); // Admin page
                    } else if ("registered".equalsIgnoreCase(role)) {
                        response.sendRedirect("user.html"); // User page
                    } else {
                        out.println("<h3>Invalid role detected in the database.</h3>");
                    }
                } else {
                    out.println("<h3>Role mismatch! Please select the correct role.</h3>");
                }
            } else {
                out.println("<h3>Invalid email or password!</h3>");
            }

            // Close resources
            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            // Exception handling
            e.printStackTrace();
            out.println("<h3>Database connection error!</h3>");
        }
    }
}
