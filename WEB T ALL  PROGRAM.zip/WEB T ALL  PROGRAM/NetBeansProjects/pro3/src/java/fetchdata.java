import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class fetchdata {
    public static void main(String[] args) {
        // Database connection details
        String url = "jdbc:mysql://localhost:3306/user"; // Replace 'your_database' with your database name
        String username = "root"; // Replace with your database username
        String password = "admin"; // Replace with your database password

        // SQL query
        String query = "SELECT id, first_name,last_name,mobile,address FROM users";

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            Connection connection = DriverManager.getConnection(url, username, password);

            // Prepare the SQL statement
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Process the result set
            System.out.println("ID\tfirst_name\t\tlast_name\tmobile\taddress");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String first_name = resultSet.getString("first_name");
                String last_name = resultSet.getString("last_name");
                int mobile = resultSet.getInt("mobile");
                String address = resultSet.getString("address");
                System.out.println(id + "\t" + first_name + "\t" + last_name +"\t" + mobile +"\t" +address );
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
