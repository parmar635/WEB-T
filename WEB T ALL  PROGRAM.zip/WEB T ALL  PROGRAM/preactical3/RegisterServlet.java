import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        String address = request.getParameter("address");
        String role = request.getParameter("role");

        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/users";
        String jdbcUsername = "root";
        String jdbcPassword = " ";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            String sql = "INSERT INTO users (first_name, last_name, password, email, mobile, address, role) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, password);
            statement.setString(4, email);
            statement.setString(5, mobile);
            statement.setString(6, address);
            statement.setString(7, role);

            int row = statement.executeUpdate();
            if (row > 0) {
                response.getWriter().write("Registration Successful!");
            } else {
                response.getWriter().write("Error during registration.");
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Database connection error.");
        }
    }
}
