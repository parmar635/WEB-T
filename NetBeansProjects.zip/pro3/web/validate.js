function validateForm() {
    let firstName = document.getElementById('firstName').value;
    let lastName = document.getElementById('lastName').value;
    let password = document.getElementById('password').value;
    let confirmPassword = document.getElementById('confirmPassword').value;
    let email = document.getElementById('email').value;
    let mobile = document.getElementById('mobile').value;
    let address = document.getElementById('address').value;
    let role = document.getElementById('role').value;

    
    if (!/^[a-zA-Z]+$/.test(firstName) || firstName.length < 2) {
        alert("First Name should contain alphabets and be at least 6 characters long.");
        return false;
    }

    
    if (!/^[a-zA-Z]+$/.test(lastName) || lastName.length < 4) {
        alert("Last Name should contain alphabets and be at least 6 characters long.");
        return false;
    }

    if (password.length < 6) {
        alert("Password must be at least 6 characters long.");
        return false;
    }

    
    if (password !== confirmPassword) {
        alert("Password and Confirm Password must match.");
        return false;
    }

   
    let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        alert("Please enter a valid email.");
        return false;
    }

  
    if (!/^\d{10}$/.test(mobile)) {
        alert("Mobile Number must be 10 digits.");
        return false;
    }

    
    if (address.trim() === "") {
        alert("Address cannot be empty.");
        return false;
    }

    
    if (role === "") {
        alert("Please select a user role.");
        return false;
    }

    return true;
}
